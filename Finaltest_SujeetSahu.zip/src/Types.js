export const PRODUCT = "PRODUCT";
